# Machine-Learning
Machine Learning course taught to the the 2021 B.Tech CSE Batch (CSE3&4) at BMU during January to June 2023.
This is a Foundation - Programme Specific course for the 2021 batch.
